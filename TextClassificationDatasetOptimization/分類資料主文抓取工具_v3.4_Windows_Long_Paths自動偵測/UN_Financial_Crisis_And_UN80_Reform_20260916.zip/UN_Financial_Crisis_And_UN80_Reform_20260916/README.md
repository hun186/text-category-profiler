# 成果清單 / README

## 本次目標
- 原始目標類別：**聯合國財政危機與聯合國80改革**
- 正式英文 label：**UN Financial Crisis And UN80 Reform**
- 產製日期：2026-09-16

## 主要成果
- `新增邊.csv`：11 條新增階層／檢索邊。
- `未採用候選邊.csv`：記錄重要但因捷徑、語意不合或關係方向問題而未採用的候選。
- `分類設計說明.md`：命名、分類軸、多父類別、檢索橋接與官方依據。
- `新增邊檢核報告.md`：捷徑、循環、label 長度、備註格式與資料品質檢查。
- `中文類別子圖.md/.png`
- `英文類別子圖.md/.png`
- `訓練資料/中文/#T#[正式label]/...`
- `訓練資料/English/#T#[正式label]/...`
- `來源清單.csv`
- `B1單篇直接來源候選清單.csv`
- `B1後續核驗轉換狀態.csv`
- `資料統計表.csv`
- `正文抓取失敗或受限來源紀錄.csv`
- `待核驗來源紀錄.csv`
- `因分類不符而剔除的候選來源紀錄.csv`
- `重複或近似重複來源剔除紀錄.csv`

## 訓練資料完成度
本包是**品質優先的種子資料集**，沒有把搜尋結果或未核驗來源冒充為100筆A類。
每個底層類別、每個語言目前提供：
- A：2
- B1：1
- B2：1
- A+B1：3 / 100

因此正式配額尚未完成；完整缺額請看 `資料統計表.csv`。

## 重要界線
1. A：已閱讀足夠實質內容並完成 Primary label 比較。
2. B1：已取得特定單篇直接 URL，但正文層級核驗仍待完成。
3. B2：只有 Bing News 搜尋集合，不計入 A+B1。
4. 本批次未保存原始全文，所有 TXT 中的分類摘要均為重新撰寫，正文統計為 0。
5. 中文與英文配額獨立計算。
6. `#T#[正式類別 label]` 目錄名稱未因路徑長度而改寫。

## 官方來源核心依據
- UN80 FAQ: https://www.un.org/un80-initiative/en/frequently-asked-questions
- UN80 Workstream 2: https://www.un.org/un80-initiative/en/report-mandate-implementation-review
- UN80 Workstream 3: https://www.un.org/un80-initiative/en/shifting-paradigms-1
- 2026 UN financial situation (Chinese A/80/440/Add.1): https://digitallibrary.un.org/nanna/record/4113616/files/A_80_440_Add.1-ZH.pdf?registerDownload=1&version=1&withMetadata=0&withWatermark=0
- 2026 contribution honour roll: https://www.un.org/en/ga/contributions/honourroll.shtml
- 2026 budget vote / financial rule reform: https://www.un.org/sg/en/content/sg/statements/2026-06-30/statement-the-secretary-general-the-general-assemblys-budget-vote
